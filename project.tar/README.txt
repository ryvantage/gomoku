Hello. This program is a simple gomoku game.

It begins at the main screen, prompting the user with 3 options. 1) Start a new game, 2) Load a game, or 3) Exit.

1) Start New Game: If the user decides to start a new game, a blank gomoku board is loaded. The gomoku board is strored inside a 15x15 matrix, which is passed to every function that needs it. Player 1 (black, x) is prompted to make his move. Each move is in the form "<row><column>". Rows are lettered A-O, and columns are numbered 1-15. At any time, the user can enter "x" to exit the program. If the user decides to exit, they are prompted to save the game or not. If they choose to save the game, they will be prompted with a filename to save to. Otherwise, the program just exits.

2) Load Game: If the user decides to load a game, they are prompted for a filename. That filename is then loaded and the game picks up where it left off when the game was saved.

3) Exit: Exits the program. =)

I wish I would have had time to write the AI. =( Oh well.

Thanks for reading. And happy playing!